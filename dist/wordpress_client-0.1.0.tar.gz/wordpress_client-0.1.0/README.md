# wordpress-py
Python package for Wordpress REST API.
Hello world!